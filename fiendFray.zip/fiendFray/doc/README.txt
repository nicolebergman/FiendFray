What works:
Guest user functionality works
Registering for a new user works
Loging in to a user who is in the database works
Pet Shop works
Leaderboard displays accurate results
Logout currectly logs out users

Nuances: 
Because our game is a multiplayer web game,
it is required that if you would like to simulate
two users playing at the same time, you must use a 
simulate two computers with two different session IDs.
To do this you can create a new chrome ID and use that to 
log in to a different user.
To battle with other users, click their name under the 
current users list. A popup will show up on the user you selected
asking them if they would like to battle, if they click "nick has challenged you to battle"
you will both be redirected to the battle page accordingly.
Battling works by taking turns placing by placing 2 cards to form
a hand of five. 
